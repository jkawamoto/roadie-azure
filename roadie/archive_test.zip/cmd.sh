#!/bin/sh
cat abc.txt
